class MJPGStream {

    async status(args) {
		let url = args.url;
		args.changeIcon(url);
        return;
    }
}

module.exports = MJPGStream;
